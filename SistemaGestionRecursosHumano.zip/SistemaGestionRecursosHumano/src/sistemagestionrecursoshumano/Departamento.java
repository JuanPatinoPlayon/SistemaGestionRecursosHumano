/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrecursoshumano;





import java.util.ArrayList;

public class Departamento {
    private static int contador = 1;
    private int id;
    private String nombre;
    private ArrayList<Empleado> empleados;
    private SistemaRecursosHumanos sistema;

    public Departamento(String nombre,SistemaRecursosHumanos sistema) {
        this.id = contador++;
        this.nombre = nombre;
        this.empleados = new ArrayList<>();
        this.sistema = sistema;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    // Agregar empleado al sistema global y al departamento
    public boolean agregarEmpleado(Empleado empleado) {
        if (sistema.agregarEmpleado(empleado)) { // Agregar al sistema
            return empleados.add(empleado); // Agregar también al departamento
        }
        return false;
    }

    // Actualizar empleado en el sistema global y reflejar cambios en el departamento
    public boolean actualizarEmpleado(int id, Empleado empleadoActualizado) {
        if (sistema.actualizarEmpleado(id, empleadoActualizado)) { // Actualizar en el sistema
            int index = buscarIndiceE(id);
            if (index >= 0) {
                empleados.set(index, empleadoActualizado); // Actualizar en el departamento
                return true;
            }
        }
        return false;
    }

    // Eliminar empleado del sistema global y del departamento
    public boolean eliminarEmpleado(int id) {
        if (sistema.eliminarEmpleado(id)) { // Eliminar del sistema
            int index = buscarIndiceE(id);
            if (index >= 0) {
                empleados.remove(index); // Eliminar del departamento
                return true;
            }
        }
        return false;
    }

    // Buscar índice de un empleado en la lista del departamento
    private int buscarIndiceE(int id) {
        for (int i = 0; i < this.empleados.size(); i++) {
            if (this.empleados.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }

    // Mostrar empleados del departamento
    public String mostrarEmpleados() {
        StringBuilder sb = new StringBuilder();
        for (Empleado empleado : this.empleados) {
            sb.append(empleado.toString()).append("\n");
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Departamento ID: " + id + "\n" +
               "Nombre: " + nombre + "\n";
    }
}