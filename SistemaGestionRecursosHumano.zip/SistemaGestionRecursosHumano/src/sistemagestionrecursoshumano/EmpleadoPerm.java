package sistemagestionrecursoshumano;

public class EmpleadoPerm extends Empleado {
    private double salario;
    private String beneficios;

    public EmpleadoPerm(String nombre, String apellido, String departamento, double salario, String beneficios) {
        super(nombre, apellido, departamento);
        this.salario = salario;
        this.beneficios = beneficios;
    }

    public double getSalario() {
        return salario;
    }

    public String getBeneficios() {
        return beneficios;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void setBeneficios(String beneficios) {
        this.beneficios = beneficios;
    }
}

