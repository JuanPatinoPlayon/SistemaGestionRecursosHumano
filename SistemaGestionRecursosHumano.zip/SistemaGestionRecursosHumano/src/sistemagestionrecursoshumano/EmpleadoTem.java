package sistemagestionrecursoshumano;

public class EmpleadoTem extends Empleado {
    private int duracionContrato;
    private double salario;

    public EmpleadoTem(String nombre, String apellido, String departamento, int duracionContrato, double salario) {
        super(nombre, apellido, departamento);
        this.duracionContrato = duracionContrato;
        this.salario = salario;
    }

    public int getDuracionContrato() {
        return duracionContrato;
    }

    public double getSalario() {
        return salario;
    }

    public void setDuracionContrato(int duracionContrato) {
        this.duracionContrato = duracionContrato;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}


