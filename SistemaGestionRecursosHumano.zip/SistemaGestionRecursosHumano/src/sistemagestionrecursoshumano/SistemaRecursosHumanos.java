/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrecursoshumano;

import java.util.ArrayList;
import java.util.List;

public class SistemaRecursosHumanos {
    private ArrayList<Empleado> empleados;
    private ArrayList<Departamento> departamentos;
    private ArrayList<ReporteDesempeño> reportes;

    public SistemaRecursosHumanos(ArrayList<Empleado> empleados, ArrayList<Departamento> departamentos) {
        this.empleados = (empleados != null) ? empleados : new ArrayList<>();
        this.departamentos = (departamentos != null) ? departamentos : new ArrayList<>();
        this.reportes = new ArrayList<>();
    }
    
    
    

    public SistemaRecursosHumanos() {
        this(new ArrayList<>(), new ArrayList<>());
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public ArrayList<Departamento> getDepartamentos() {
        return departamentos;
    }

    public void setDepartamentos(ArrayList<Departamento> departamentos) {
        this.departamentos = departamentos;
    }

    // Métodos de gestión CRUD

    // Agregar Empleado
    public boolean agregarEmpleado(Empleado empleadito) {
        return this.empleados.add(empleadito);
    }

    // Buscar empleado por ID
    public Empleado buscarEmpleado(int id) {
        try {
            for (Empleado p : this.empleados) {
            if (p.getId() == id) {
                return p;
            }
        }
    } catch (Exception e) {
            System.out.println("Error en tiempo de ejecución ");
    }
        return null;
    }
    
    // Buscar empleado por nombre
    public Empleado buscarEmpleado(String nombre) {
        try {
            for (Empleado p : this.empleados) {
                
            if (p.getNombre().trim().equalsIgnoreCase(nombre)) {
                return p;
            }
        }
    } catch (Exception e) {
            System.out.println("Error en tiempo de ejecución ");
    }
        return null;
    }
       
        
    
    // Buscar índice de un empleado en la lista
    private int buscarIndiceE(int id) {
        try {
        for (int i = 0; i < this.empleados.size(); i++) {
            if (this.empleados.get(i).getId() == id) {
                return i;
            }
        }
        } catch (Exception e) {
            System.out.println("Error en tiempo de ejecución ");
    }
        
        return -1;
        
    }

    // Actualizar Empleado
    public boolean actualizarEmpleado(int id, Empleado empleadoActualizado) {
    int index = this.buscarIndiceE(id);

    if (index >= 0) {
        Empleado empleadoAntiguo = this.empleados.get(index);
        this.empleados.set(index, empleadoActualizado); 

        // actualizar también en su departamento
        for (Departamento departamento : this.departamentos) {
            int indexDep = departamento.getEmpleados().indexOf(empleadoAntiguo);
            if (indexDep >= 0) {
                departamento.getEmpleados().set(indexDep, empleadoActualizado);
            }
        }

        return true;
    }
    
    return false;
}
    

    // Eliminar Empleado
    public boolean eliminarEmpleado(int id) {
        int index = this.buscarIndiceE(id);
        if (index >= 0) {
            this.empleados.remove(index);
            return true;
        }
        return false;
    }
    
    
    //Obtener Empleados
    public ArrayList<Empleado> obtenerEmpleados(){
        return this.getEmpleados();
    }
    
    
    // Agregar un empleado a un departamento específico
    
public boolean agregarEmpleadoADepartamento(int idEmpleado, int idDepartamento) {
    Empleado empleado = buscarEmpleado(idEmpleado); 
    Departamento departamento = buscarDepartamento(idDepartamento); 

    if (empleado != null && departamento != null) {
        if (!departamento.getEmpleados().contains(empleado)) { 
            return departamento.agregarEmpleado(empleado); 
        } else {
            System.out.println("El empleado ya pertenece a este departamento.");
            return false;
        }
    } else {
        System.out.println("Error: Empleado o departamento no encontrado.");
        return false;
    }
}

    public boolean iniciarSesion(String nombre, int id) {
    for (Empleado emp : empleados) {
        if (emp.getNombre().equals(nombre) && emp.getId() == id) {
            return true;
        }
    }
    return false;
    }
    
    
    
    

    // Mostrar empleados
    public String mostrarEmpleados() {
        StringBuilder sb = new StringBuilder();
        for (Empleado p : this.empleados) {
            sb.append(p.toString()).append("\n");
        }
        return sb.toString();
    }

    // Crear Departamento
    public boolean crearDepartamento(Departamento departamento) {
        return this.departamentos.add(departamento);
    }

    // Buscar Departamento por ID
    public Departamento buscarDepartamento(int id) {
        try {
        for (Departamento p : this.departamentos) {
            if (p.getId() == id) {
                return p;
            }
        }
        } catch (Exception e) {
            System.out.println("Error en tiempo de ejecución ");
    }
        return null;
    }
    
    // Buscar Departamento por nombre
    public Departamento buscarDepartamento(String nombre) {
        try {
        for (Departamento p : this.departamentos) {
            if (p.getNombre().equals(nombre)) {
                return p;
            }
        }
        } catch (Exception e) {
            System.out.println("Error en tiempo de ejecución ");
    }
        return null;
    }

    // Buscar índice de un departamento en la lista
    private int buscarIndiceD(int id) {
        try {
        for (int i = 0; i < this.departamentos.size(); i++) {
            if (this.departamentos.get(i).getId() == id) {
                return i;
            }
        }
        } catch (Exception e) {
            System.out.println("Error en tiempo de ejecución ");
    }
        return -1;
    }

    // Actualizar Departamento
    public boolean actualizarDepartamento(int id, Departamento departamento) {
        int index = this.buscarIndiceD(id);
        if (index >= 0) {
            this.departamentos.set(index, departamento);
            return true;
        }
        return false;
    }

    // Eliminar Departamento
    public boolean eliminarDepartamento(int id) {
        int index = this.buscarIndiceD(id);
        if (index >= 0) {
            this.departamentos.remove(index);
            return true;
        }
        return false;
    }
    
    //Obtener Departamentos
    public ArrayList<Departamento> obtenerDepartamento(){
        return this.getDepartamentos();
    }

    // Mostrar departamentos
    public String mostrarDepartamentos() {
        StringBuilder sb = new StringBuilder();
        for (Departamento p : this.departamentos) {
            sb.append(p.toString()).append("\n");
        }
        return sb.toString();
    }

    // Agregar Reporte de Desempeño
    public boolean agregarReporte(ReporteDesempeño reporte) {
        return this.reportes.add(reporte);
    }

    // Buscar Reporte 
    public ReporteDesempeño buscarReporte(int id) {
        for (ReporteDesempeño reporte : reportes) {
            if (reporte.getId() == id) {
                return reporte;
            }
        }
        return null;
    }

    // Eliminar Reporte 
    public boolean eliminarReporte(int id) {
        ReporteDesempeño reporte = buscarReporte(id);
        if (reporte != null) {
            return reportes.remove(reporte);
        }
        return false;
    }

    // Mostrar todos los reportes
    public String mostrarReportes() {
        StringBuilder sb = new StringBuilder();
        for (ReporteDesempeño reporte : reportes) {
            sb.append("ID: ").append(reporte.getId())
              .append(", Tipo: ").append(reporte.getTipo())
              .append(", Evaluación: ").append(reporte.getEvaluacion())
              .append(", Empleado: ").append(reporte.getEmpleado().getNombre())
              .append("\n");
        }
        return sb.toString();
    }
    
    public List<String> getNombresDepartamentos() {
    List<String> nombres = new ArrayList<>();
    for (Departamento d : this.departamentos) {
        nombres.add(d.getNombre());
    }
    return nombres;
    }


}