/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrecursoshumano;

/**
 *
 * @author juanc
 */
public class ReporteDesempeño {
   
   private static int ContadorReportes=1;
    
   private int id;
   private String tipo;        
   private Empleado empleado;
   private int evaluacion;

    public ReporteDesempeño(String tipo,Empleado empleado, int evaluacion) {
        this.id =ContadorReportes;   
        this.empleado = empleado;
        this.tipo=tipo;
        this.evaluacion = evaluacion;
        ContadorReportes++;
    }

    public static int getContadorReportes() {
        return ContadorReportes;
    }

    public static void setContadorReportes(int ContadorReportes) {
        ReporteDesempeño.ContadorReportes = ContadorReportes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public int getEvaluacion() {
        return evaluacion;
    }

    public void setEvaluacion(int evaluacion) {
        this.evaluacion = evaluacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
     @Override
    public String toString() {
        return "ID: " + id + ", Tipo: " + tipo + ", Evaluación: " + evaluacion +
               ", Empleado: " + empleado.getNombre();
    }
}
