/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrecursoshumano;

/**
 *
 * @author juanc
 */
public abstract class Empleado {
    
    private static int contadorEmpleados=1;
    
    
    private int id;
    private String nombre;
    private String apellido;
    private String departamento;

    public Empleado( String nombre, String apellido, String departamento) {
        this.id = contadorEmpleados;
        this.nombre = nombre;
        this.apellido = apellido;
        this.departamento = departamento;
        contadorEmpleados++;
        
      
    }

    public Empleado() {
        this.id = contadorEmpleados;
        this.nombre = "";
        this.apellido = "";
        this.departamento ="";
        contadorEmpleados++;
    }
    

    public static int getContadorEmpleados() {
        return contadorEmpleados;
    }

    

    public int getId() {
        return id;
    }

    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
    
    
    @Override
    public String toString(){
     return  "Empleado: " + id + "\n"+
             "Nombre: " + nombre+ "\n" +
             "Apellido: "+ apellido+"\n"+
             "Departamento: "+departamento+"\n";
    }
    
}
