/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestionrecursoshumano;

import SIstemaDeGestion.Presentacion.VentanaPrincipal;
import SIstemaDeGestion.Presentacion.iniciarSesion;
import SIstemaDeGestion.Presentacion.agregarDepartamento;

public class SistemaGestionRecursosHumano {

    
    public static void main(String[] args) {
        
    SistemaRecursosHumanos sistema = new SistemaRecursosHumanos();
    
    Departamento dpto1 = new Departamento("Recursos Humanos",sistema);
    sistema.crearDepartamento(dpto1);
    
    
    
    EmpleadoPerm emp = new EmpleadoPerm("Juan", "Perez", "Contabilidad", 1600000, "Seguridad Social");
    sistema.agregarEmpleado(emp);
    
    
    VentanaPrincipal ventana = new VentanaPrincipal(sistema);
    
    iniciarSesion sesion = new iniciarSesion(ventana, true, sistema, ventana);
    sesion.setVisible(true);
    
    ventana.setVisible(true);
    
    agregarDepartamento agregar = new agregarDepartamento(ventana, true, sistema, ventana);
    agregar.setVisible(true);
        
    }
    
    
}